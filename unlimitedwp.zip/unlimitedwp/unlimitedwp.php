<?php
/*
 * Plugin Name:       Unlimited WP Plugin Post Type
 * Plugin URI:        http://example.com/plugin-name-uri/
 * Description:       This plugin will create custom post type, with taxonomies
 * Version:           1.0.0
 * Author:            Akshay Saxena
 * Author URI:        http://example.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       plugin-name
 * Domain Path:       /languages
 */


add_action( 'init', 'create_resources_cpt', 0 );
require_once plugin_dir_path( __FILE__ ) . 'functions.php';

// Register Custom Post Type Resources
function create_resources_cpt() {

	$labels = array(
		'name' => _x( 'Resources', 'Post Type General Name', 'textdomain' ),
		'singular_name' => _x( 'Resources', 'Post Type Singular Name', 'textdomain' ),
		'menu_name' => _x( 'Resources', 'Admin Menu text', 'textdomain' ),
		'name_admin_bar' => _x( 'Resources', 'Add New on Toolbar', 'textdomain' ),
		'archives' => __( 'Resources Archives', 'textdomain' ),
		'attributes' => __( 'Resources Attributes', 'textdomain' ),
		'parent_item_colon' => __( 'Parent Resources:', 'textdomain' ),
		'all_items' => __( 'All Resources', 'textdomain' ),
		'add_new_item' => __( 'Add New Resources', 'textdomain' ),
		'add_new' => __( 'Add New', 'textdomain' ),
		'new_item' => __( 'New Resources', 'textdomain' ),
		'edit_item' => __( 'Edit Resources', 'textdomain' ),
		'update_item' => __( 'Update Resources', 'textdomain' ),
		'view_item' => __( 'View Resources', 'textdomain' ),
		'view_items' => __( 'View Resources', 'textdomain' ),
		'search_items' => __( 'Search Resources', 'textdomain' ),
		'not_found' => __( 'Not found', 'textdomain' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'textdomain' ),
		'featured_image' => __( 'Featured Image', 'textdomain' ),
		'set_featured_image' => __( 'Set featured image', 'textdomain' ),
		'remove_featured_image' => __( 'Remove featured image', 'textdomain' ),
		'use_featured_image' => __( 'Use as featured image', 'textdomain' ),
		'insert_into_item' => __( 'Insert into Resources', 'textdomain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Resources', 'textdomain' ),
		'items_list' => __( 'Resources list', 'textdomain' ),
		'items_list_navigation' => __( 'Resources list navigation', 'textdomain' ),
		'filter_items_list' => __( 'Filter Resources list', 'textdomain' ),
	);
	$args = array(
		'label' => __( 'Resources', 'textdomain' ),
		'description' => __( 'Add Resources to site', 'textdomain' ),
		'labels' => $labels,
		'menu_icon' => '',
		'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'author', 'custom-fields'),
		'taxonomies' => array(),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => true,
		'has_archive' => true,
		'hierarchical' => true,
		'exclude_from_search' => false,
		'show_in_rest' => true,
		'publicly_queryable' => true,
		'capability_type' => 'post',
	);

	// For custom taxonomy Category
	 $labels = array(
    'name' => _x( 'Categories', 'taxonomy general name' ),
    'singular_name' => _x( 'Categories', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Categories' ),
    'all_items' => __( 'All Categories' ),
    'parent_item' => __( 'Parent Categories' ),
    'parent_item_colon' => __( 'Parent Categories:' ),
    'edit_item' => __( 'Edit Categories' ), 
    'update_item' => __( 'Update Categories' ),
    'add_new_item' => __( 'Add New Categories' ),
    'new_item_name' => __( 'New Categories Name' ),
    'menu_name' => __( 'Categories' ),
  	); 
	
	// For custom taxonomy Category
	 register_taxonomy('Categories','resources', array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
  'show_in_quick_edit' => true,
  'update_count_callback' => '_update_post_term_count',
    'query_var' => true,  //optional
    'rewrite' => array( 'slug' => 'category' ), //optional
  'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields','excerpt','page-attributes' ),
  	'show_in_rest' =>true,
  ));


	 // For custom tags Category
	 $labels = array(
    'name' => _x( 'Tags', 'taxonomy general name' ),
    'singular_name' => _x( 'Tags', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Tags' ),
    'all_items' => __( 'All Tags' ),
    'parent_item' => __( 'Parent Tags' ),
    'parent_item_colon' => __( 'Parent Tags:' ),
    'edit_item' => __( 'Edit Tags' ), 
    'update_item' => __( 'Update Tags' ),
    'add_new_item' => __( 'Add New Tags' ),
    'new_item_name' => __( 'New Tags Name' ),
    'menu_name' => __( 'Tags' ),

  	); 
	
	// For custom tags Category
	 register_taxonomy('Tags','resources', array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
  'show_in_quick_edit' => true,
  'update_count_callback' => '_update_post_term_count',
    'query_var' => true,  //optional
    'rewrite' => array( 'slug' => 'category' ), //optional
  'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields','excerpt','page-attributes' ),
  'show_in_rest' =>true,
  ));

	 $parent_term = term_exists( 'Category ', 'Categories' ); // array is returned if taxonomy is given
		$parent_term_id = $parent_term['term_id'];         // get numeric term id
		wp_insert_term(
		    'Blog',   // the term 
		    'Categories', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'blog',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Brochures',   // the term 
		    'Categories', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'brochures',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Case Studies',   // the term 
		    'Categories', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'case-studies',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Company Announcements',   // the term 
		    'Categories', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'company-announcements',
		        'parent'      => $parent_term_id,
		    )
		);

		// code for tags taxonomy

		 $parent_term = term_exists( 'Tag ', 'Tags' ); // array is returned if taxonomy is given
		$parent_term_id = $parent_term['term_id'];         // get numeric term id
		wp_insert_term(
		    'Carrier ',   // the term 
		    'Tags', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'carrier',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Cloud',   // the term 
		    'Tags', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'cloud',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Managed Services',   // the term 
		    'Tags', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'managed-services',
		        'parent'      => $parent_term_id,
		    )
		);

		wp_insert_term(
		    'Microsoft',   // the term 
		    'Tags', // the taxonomy
		    array(
		        'description' => '',
		        'slug'        => 'microsoft',
		        'parent'      => $parent_term_id,
		    )
		);








	register_post_type( 'resources', $args );

}

// for creating a page

	  function createpage(){
	   $post = array(
	          'comment_status' => 'open',
	          'ping_status' =>  'closed' ,
	          'post_author' => 1,
	          'post_date' => date('Y-m-d H:i:s'),
	          'post_name' => 'Checklists',
	          'post_status' => 'publish' ,
	          'post_title' => 'Checklists',
	          'post_type' => 'page',
	          'page_template'  => 'archive-resources.php'
	    );  
	    //insert page and save the id
	    if(!is_page( 'Checklists' )){
	    	$newvalue = wp_insert_post( $post, false );
	    }
	    //save the id in the database
	    update_option( 'hclpage', $newvalue );
	}



 function unlimitedwp_flush_rewrites() {
                create_resources_cpt();
                flush_rewrite_rules();
                createpage();

        }


//register_activation_hook( __FILE__, 'create_resources_cpt' );

register_activation_hook( __FILE__, 'unlimitedwp_flush_rewrites' );

register_uninstall_hook( __FILE__, 'unlimitedwp_uninstall' );
        function unlimitedwp_uninstall() {
          // Uninstallation stuff here
             $page = get_page_by_path( 'Checklists' );
    			wp_delete_post($page->ID);

                
        }

?>