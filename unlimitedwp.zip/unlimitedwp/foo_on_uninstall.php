<?php
global $wpdb;
$del_prefix = $wpdb->prefix;

//if uninstall not called from WordPress exit


//=========> Delete foo Options
    delete_option('foo_theme_directory');
    delete_option('foo_plugin_slug');
    delete_option('foo_article_qty');
    delete_option('foo_search_setting');
    delete_option('foo_breadcrumbs_setting');
    delete_option('foo_sidebar_setting');
    delete_option('foo_comments_setting');
    delete_option('foo_bgcolor');
    delete_option('widget_foo_article_widget');
    delete_option('foo_cat_children');

//=========> Get and Delete Foo Page
     $foo_get_page = $wpdb->get_results("SELECT * FROM ".$del_prefix."posts WHERE   post_name = 'Checklists'",ARRAY_A );

    $fooPageID = $foo_get_page['ID'];

    $wpdb->query("DELETE FROM ".$del_prefix."postmeta WHERE post_id = '$fooPageID'");

    $wpdb->query("DELETE FROM ".$del_prefix."posts WHERE post_title Like '%article%' And post_type = 

'page'");

// //=========> Delete foo Terms and Taxonomies
//     $foo_Find_tax = $wpdb->get_results("SELECT term_taxonomy_id FROM ".$del_prefix."term_taxonomy WHERE 

// taxonomy='foo_article'",ARRAY_A );
//     $fooTaxID = $foo_Find_tax[0]['term_taxonomy_id'];

//     foreach($foo_Find_tax as $foo_find_tax){
//     $fooTaxID = $foo_find_tax['term_taxonomy_id'];

//     $delete_foo_relations = $wpdb->query("DELETE FROM ".$del_prefix."term_relationships WHERE 

// term_taxonomy_id='$fooTaxID'");
//     $delete_foo_tax = $wpdb->query("DELETE FROM ".$del_prefix."term_taxonomy WHERE 

// term_taxonomy_id='$fooTaxID'");
//     $delete_foo_terms = $wpdb->query("DELETE FROM ".$del_prefix."terms WHERE term_id='$fooTaxID'");
//     }

// //=========> Delete terms_order From wp_terms
//     $wpdb->query("ALTER TABLE ".$del_prefix."terms DROP `terms_order`");

// //=========> Delete comments of articles
//     $foo_comments = $wpdb->get_results("SELECT ID FROM ".$del_prefix."posts WHERE post_type = 

// 'foo_article'");

//     $foo_comment_id = $foo_comments->ID;

//     foreach($foo_comments as $foo_comment){
//         $foo_comment_id = $foo_comment->ID;
//         $wpdb->query("DELETE FROM ".$del_prefix."comments WHERE comment_post_ID='$foo_comment_id'");
//     }

// //=========> Delete All Articles and Attachments
//     $foo_all_articles = new WP_Query('post_type=foo_article&posts_per_page=-1');

//     if($foo_all_articles){
//         while($foo_all_articles->have_posts()) :
//             $foo_all_articles->the_post();
//             $fooID = get_the_id();

//             $foo_del_args = array('post_parent' => $fooID);
//             $foo_attachments = get_children($foo_del_args);

//             if($foo_attachments){
//                 foreach($foo_attachments as $foo_attachment){
//                     wp_delete_attachment($foo_attachment->ID, true);
//                 }
//             }
//             wp_delete_post($fooID, true);
//         endwhile;
//     }

// //=========> Remove all files and images
//     unlink(get_template_directory()."/foo_articles.php");
//     unlink(get_template_directory()."/foo_style.css");
//     unlink(get_template_directory()."/single-foo_articles.php");
//     unlink(get_template_directory()."/taxonomy-foo_cat.php");
//     unlink(get_template_directory()."/foo_search.php");

?>