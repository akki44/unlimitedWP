<?php
add_action('init', 'register_script');

add_action( 'wp_ajax_nopriv_get_data', 'get_data' );
add_action( 'wp_ajax_get_data', 'get_data' );


function register_script(){
	wp_register_script( 'custom_jquery', plugins_url('includes/js/jquery-min.js', __FILE__), array('jquery') );

	wp_register_style( 'style', plugins_url('includes/css/style.css', __FILE__), false, '1.0.0', 'all');
}

// use the registered jquery and style above
add_action('wp_enqueue_scripts', 'enqueue_style');
function enqueue_style(){
	wp_enqueue_script('custom_jquery');

	wp_enqueue_style( 'style' );
}


function get_data() {
        
        $value = $_POST['value'];
        
       $custom_terms = get_terms($value);
      

foreach($custom_terms as $custom_term) {

    $args = array('post_type' => 'resources',
        'tax_query' => array(
            array(
                'taxonomy' => $value,
                'field' => 'slug',
                'terms' => $custom_term->slug,
            ),
        ),
     );

     $loop = new WP_Query($args);
     if($loop->have_posts()) {
     	 $terms = get_the_terms( $loop->ID, 'Tags' );
     	$terms_string = join(', ', wp_list_pluck($terms, 'name'));
      
        
        while($loop->have_posts()) : $loop->the_post(); ?>
            <?php
        $post_type = get_post_type(get_the_ID());   
        $taxonomies = get_object_taxonomies($post_type); 
        $taxonomy_names = wp_get_object_terms(get_the_ID(), 'Tags',  array("fields" => "names")); 
            ?>
        	<div class="width30">
              
        		<?php  echo '<h2>'.$custom_term->name.'</h2><br>'; ?>
           <?php echo '<a href="'.get_permalink().'"><b>Title: </b>'.get_the_title().'</a><br>'; ?>
           <?php 
              if(!empty($taxonomy_names)) :
               foreach($taxonomy_names as $tax_name) : ?>              
                  <span><b>Tags</b>: <?php echo $tax_name; ?> </span>
               <?php endforeach;
            endif;

              ?>
           <?php echo '<p><b>Content</b>: '.get_the_excerpt().'<p>'; ?>
        	</div>


        
        <?php endwhile;
     }
     
}

        die();  //die();
    }
?>